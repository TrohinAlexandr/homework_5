/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dom_rabota5;

/**
 *
 * @author User
 */
import java.io.File;
import java.util.*;

public class DOM_RABOTA5 {
    public static void main(String[] args) {
        System.out.println("Трохин Александр Андреевич");
        System.out.println("РИБО-01-21");

        String path;
        File userFile;
        while (true) {
            System.out.println();
            System.out.println("Укажите путь к директории:");
            System.out.println("Пример: С:\\Users\\Admin\\Some_Directory");

            path = new Scanner(System.in).nextLine();

            if (path.isEmpty() || path.isBlank()) {
                System.out.println("Поле \"Путь\" должно быть заполнено");
                continue;
            }

            userFile = new File(path);

            if (!userFile.exists()) {
                System.out.println("Директория по такому пути отсутсвует");
                continue;
            }

            if (!userFile.isDirectory()) {
                System.out.println("Необходимо указать директорию, а не файл");
                continue;
            }
            break;
        }

        String fileExtension;
        while (true) {
            System.out.println();
            System.out.println("Введите расширение файлов, которые необходимо найти:");
            System.out.println("Пример: txt или docx и т.п. (Без точки):");

            fileExtension = new Scanner(System.in).nextLine();

            if (fileExtension.isEmpty() || fileExtension.isBlank()) {
                System.out.println("Поле \"Расширение\" должно быть заполнено");
                continue;
            }
            break;
        }

        System.out.println();
        System.out.println("Выполняем поиск по директории...");
        System.out.println();

        List<File> files = new ArrayList<>();
        Queue<File> que = new LinkedList<>();
        que.add(userFile);
        while (que.peek() != null) {
            File directory = que.remove();
            for(File file : directory.listFiles())
            {
                if(file.isDirectory())
                    que.add(file);
                else {
                    if (file.getName().endsWith("." + fileExtension)) {
                        files.add(file);
                    }
                }
            }
        }

        for (File file : files) {
            System.out.println(file.getAbsolutePath() + " " + file.length());
        }
    }
}
